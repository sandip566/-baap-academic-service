module.exports = {
    name: {
        notEmpty: true,
    }
}
