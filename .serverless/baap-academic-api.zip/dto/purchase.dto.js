module.exports = {}

